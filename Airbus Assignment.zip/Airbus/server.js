// Add this line at the beginning of your server.js file
require('events').EventEmitter.defaultMaxListeners = 25; // or any appropriate value

// Increase the limit for the TLSSocket event emitter
const tls = require('tls');
tls.DEFAULT_MAX_LISTENERS = 25; // or any appropriate value

// Your remaining server.js code...
const express = require('express');
const app = express();
const port = 3000;

// Serve static files from the public directory
app.use(express.static('public'));

// Define routes
app.get('/', (req, res) => {
    res.sendFile(__dirname + '/public/index.html');
});

// Start the server
app.listen(port, () => {
    console.log(`Server is listening at http://localhost:${port}`);
});
